from handlers import commands 
from handlers import slogans 
from handlers import schedule