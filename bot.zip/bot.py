from create_bot import bot

bot.polling(none_stop=True, interval=0)
